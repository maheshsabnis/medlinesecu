import { Injectable } from '@angular/core';

@Injectable()
export class UtilityService {
    changeCase(str: string, choice: string): string {
        let res: string = '';
        if (str !== 'undefined' || str.length > 0) {
            if (choice === "L") {
                res = str.toLowerCase();
            }
            if (choice === "U") {
                res = str.toUpperCase();
            }
        }
        return res;
    }
}