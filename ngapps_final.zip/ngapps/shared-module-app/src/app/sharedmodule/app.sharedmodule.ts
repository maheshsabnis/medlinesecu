import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UtilityService } from './app.utility.service';

@NgModule({
    declarations: [],
    imports: [CommonModule],
    exports: [CommonModule],
    providers: [UtilityService],
})
export class FeatureModule { }