import { Component } from '@angular/core';
import { UtilityService } from './sharedmodule/app.utility.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  title: string;
  constructor(private serv: UtilityService) {
    this.title = this.serv.changeCase('Angular', 'U');
  }
}
