import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

if (environment.production) {
  enableProdMode();
}
// the platformBrowserDynamic is bootstratping the AppModule
// and hence all objects in AppModule will be loaded for execution 
platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));
