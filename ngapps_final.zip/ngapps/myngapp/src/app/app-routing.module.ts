import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/routeapp/app.home.component';
import { ContactComponent } from './components/routeapp/app.contact.component';
import { AboutComponent } from './components/routeapp/app.about.component';
import { ProductFormComponent } from './components/productformcomponent/app.productform.component';
// route table
const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'about/:id', component: AboutComponent },
  {
    path: 'contact', component: ContactComponent,
    children: [
      { path: 'product', component: ProductFormComponent }
    ]
  }
];

// the RouterModule.forRoot(routes), will provide the
// router table to to AppModule at Application root
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
