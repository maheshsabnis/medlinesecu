import { Injectable } from '@angular/core';
import { Register, Login, ResponseData, ProductResponse, AuthValue } from '../models/app.security.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class AuthenticationService {
    url: string;

    constructor(private http: HttpClient) {
        this.url = 'http://localhost:16237/api/Authentication';
    }

    register(regInfo: Register): Observable<ResponseData> {
        let resp: Observable<ResponseData>;
        const options = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        };
        resp = this.http.post<ResponseData>(`${this.url}/Register`, JSON.stringify(regInfo), options);
        return resp;
    }

    login(logInfo: Login): Observable<ResponseData> {
        let resp: Observable<ResponseData>;
        const options = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        };
        resp = this.http.post<ResponseData>(`${this.url}/Login`, JSON.stringify(logInfo), options);
        return resp;
    }

    getProducts(authValue: AuthValue): Observable<ProductResponse[]> {
        let resp: Observable<ProductResponse[]>;
        const options = {
            headers: new HttpHeaders(
                {
                    Authorization: `Bearer grant_type ${authValue.TokenValue}`
                })
        };
        resp = this.http.get<ProductResponse[]>('http://localhost:16237/api/Products', options);
        return resp;
    }

}
