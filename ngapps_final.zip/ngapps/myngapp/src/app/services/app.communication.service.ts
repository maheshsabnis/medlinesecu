import { Injectable, EventEmitter } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class CommunicationService {
    // the public event emitter
    // this will be used by the sender 
    // to emit an event and pass the payload
    onReceiveData: EventEmitter<number>;

    constructor() {
        this.onReceiveData = new EventEmitter<number>();
    }

    // a method that will be accessed by the sender
    // to pass the data and emit event

    receiveData(id: number): void {
        this.onReceiveData.emit(id);
    }
}
