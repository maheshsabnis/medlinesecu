import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SimpleComponent } from './components/simplecomponent/app.simple.component';
import { ProductComponent } from './components/productcomponent/app.product.component';
import { ProductFormComponent } from './components/productformcomponent/app.productform.component';
import { DepartmentComponent } from './components/masterdetails/app.department.component';
import { EmployeeComponent } from './components/masterdetails/app.emp.component';
import { Utilities } from './services/app.sample.service';
import { SampleServiceComponent } from './components/sampleservicecomponent/app.sampleservice.component';
import { HttpServiceComponent } from './components/servicecomppnent/app.httpservice.component';
import { SecurityComponent } from './components/securitycomponent/app.security.component';
import { DepartmentSenderComponent } from './components/masterdetailsservices/app.department.component';
import { EmployeeReceiverComponent } from './components/masterdetailsservices/app.emp.component';
import { ColorDirective } from './directives/app.color.directive';
import { HomeComponent } from './components/routeapp/app.home.component';
import { AboutComponent } from './components/routeapp/app.about.component';
import { ContactComponent } from './components/routeapp/app.contact.component';
import { MainComponent } from './components/routeapp/app.main.component';
import { PipedComponent } from './components/pipedcomponent/app.pipe.component';
import { CustomPipeComponent } from './components/pipedcomponent/app.custom.pipe.component';
import { ProductFilterPipe } from './components/pipedcomponent/app.cutompipe';
@NgModule({
  declarations: [
    AppComponent, SimpleComponent, ProductComponent,
    ProductFormComponent,
    DepartmentComponent,
    EmployeeComponent,
    SampleServiceComponent,
    HttpServiceComponent, SecurityComponent,
    DepartmentSenderComponent,
    EmployeeReceiverComponent,
    ColorDirective,
    HomeComponent,
    AboutComponent,
    ContactComponent,
    MainComponent,
    PipedComponent,
    CustomPipeComponent,
    ProductFilterPipe
  ],
  imports: [
    BrowserModule, FormsModule, ReactiveFormsModule,
    AppRoutingModule, HttpClientModule
  ],
  providers: [Utilities],
  bootstrap: [CustomPipeComponent]
})
export class AppModule { }
