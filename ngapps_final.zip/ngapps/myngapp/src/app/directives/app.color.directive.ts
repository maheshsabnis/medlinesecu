import { Directive, Input, ElementRef, Renderer, HostListener } from '@angular/core';

@Directive({
    selector: '[setColor]',
})
export class ColorDirective {
    @Input('setColor') setColor: string;

    // the BrowserModule will manage the instances for Ctor parameters
    constructor(private ele: ElementRef, private render: Renderer) {
    }
    // actual directive logic
    private applyColor(color: string): void {
        this.render.setElementStyle(this.ele.nativeElement,
            'backgroundColor', color);
    }
    // methods to host events for directive activation
    @HostListener('mouseenter')
    onMouseEnter(): void {
        this.applyColor(this.setColor || 'red');
    }
    @HostListener('mouseleave')
    onMouseLeave(): void {
        this.applyColor(null);
    }

}
