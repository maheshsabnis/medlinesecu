import { Component } from '@angular/core';

@Component({
    selector: 'app-simple-component',
    template: `
        <h2>The Simple Component!!!!</h2>
        <div class="container">{{message}}--{{2+3}}</div>
        <br/>
        <input type="text" class="form-control" [value]="message"/>
        <a [href]="url">DEV-C</a>
        <br/>
        <input type="button" value="click me" class="btn btn-success" (click)="display()"/> 
        <br/>
        <input type="text" class="form-control" [(ngModel)]="name"/>
        <br/>
        <input type="text" class="form-control" [(ngModel)]="name"/>
        <br/>
        <input type="text" class="form-control" [(ngModel)]="name"/>

    `
})
export class SimpleComponent {
    message: string;
    url: string;
    name: string;
    constructor() {
        this.message = 'Hello Angular';
        this.url = 'http://www.devcurry.com';
        this.name = '';
    }
    display(): void {
        this.message = 'Message with click';
    }
}
