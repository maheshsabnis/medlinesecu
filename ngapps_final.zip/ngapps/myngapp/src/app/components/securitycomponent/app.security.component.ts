import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/services/app.authentication.service';
import { Register, Login, ResponseData, AuthValue, ProductResponse } from 'src/app/models/app.security.model';

@Component({
    selector: 'app-security-component',
    templateUrl: './app.security.view.html'
})
export class SecurityComponent implements OnInit {
    register: Register;
    login: Login;
    respoData: ResponseData;
    authValue: AuthValue;
    message: string;
    products: Array<ProductResponse>;
    constructor(private serv: AuthenticationService) {
        this.register = new Register('', '', '');
        this.login = new Login('', '');
        this.authValue = new AuthValue();
        this.respoData = new ResponseData('');
        this.message = '';
        this.products = new Array<ProductResponse>();
    }

    ngOnInit(): void { }

    registerUser(): void {
        this.serv.register(this.register).subscribe((resp: ResponseData) => {
            this.message = resp.Message;
        });
    }

    loginUser(): void {
        this.serv.login(this.login).subscribe((resp: ResponseData) => {
            this.authValue.TokenValue = resp.Message;
            console.log(this.authValue.TokenValue);
        });
    }

    getProducts(): void {
        this.serv.getProducts(this.authValue).subscribe((resp) => {
            this.products = resp;
        }, (error) => {
            this.message = error.statusCode;
        });
    }
}
