import { Component, OnInit } from '@angular/core';
import { Department, Depts } from './../../models/app.combine.models';

@Component({
    selector: 'app-dept-component',
    template: `
      <h2>List of Departments</h2>
      <div>{{message}}</div>  
      <table class="table table-bordered table-striped">
         <thead>
           <tr>
            <td>DeptNo</td>
            <td>DeptName</td>
           </tr>
         </thead>
         <tbody>
            <tr *ngFor="let d of depts" (click)="getSelectedDept(d)">
              <td>{{d.DeptNo}}</td>
              <td>{{d.DeptName}}</td>
            </tr>
         </tbody>
      </table>
      <hr>
      <app-emp-component [DeptNo]="dept.DeptNo" (onNotify)="receive($event)"></app-emp-component>
    `
})
export class DepartmentComponent implements OnInit {
    dept: Department;
    depts = Depts;
    message: string;
    constructor() {
        this.dept = new Department(0, '');
        this.message = ''
    }

    getSelectedDept(d: Department): void {
        this.dept = d;
    }
    ngOnInit(): void { }

    receive($event): void {
        this.message = $event;
    }
}
