import { Component, OnInit } from '@angular/core';
import { Department, Depts } from '../../models/app.combine.models';
import { CommunicationService } from 'src/app/services/app.communication.service';

@Component({
  selector: 'app-deptsender-component',
  template: `
      <h2>List of Departments</h2>
      <table class="table table-bordered table-striped">
        <tr>
          <td>
            <input type="radio" name="r" (click)="color='blue'"/>Blue
          </td>
          <td>
            <input type="radio" name="r" (click)="color='yellow'"/>Yellow
          </td>
          <td>
            <input type="radio" name="r" (click)="color='cyan'"/>Cyan
          </td>
        </tr>
      </table>
      <table class="table table-bordered table-striped">
         <thead>
           <tr>
            <td>DeptNo</td>
            <td>DeptName</td>
           </tr>
         </thead>
         <tbody>
            <tr *ngFor="let d of depts" (click)="getSelectedDept(d)" 
            [setColor]="color">
              <td>{{d.DeptNo}}</td>
              <td>{{d.DeptName}}</td>
            </tr>
         </tbody>
      </table>
      <hr>
    `
})
export class DepartmentSenderComponent implements OnInit {
  dept: Department;
  depts = Depts;
  color: string;
  message: string;
  constructor(private serv: CommunicationService) {
    this.dept = new Department(0, '');
    this.message = ''
    this.color = '';
  }

  getSelectedDept(d: Department): void {
    this.dept = d;
    this.serv.receiveData(this.dept.DeptNo);
  }
  ngOnInit(): void { }


}
