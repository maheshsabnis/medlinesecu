import { Component, OnInit } from '@angular/core';
import { Employee, Emps } from '../../models/app.combine.models';
import { CommunicationService } from 'src/app/services/app.communication.service';
@Component({
    selector: 'app-empreceiver-component',
    template: `
      <h2>List of Employees</h2>
      <table class="table table-bordered table-striped">
         <thead>
           <tr>
           <td>EmpNo</td>
            <td>EmpName</td>
            <td>DeptNo</td>
           </tr>
         </thead>
         <tbody>
            <tr *ngFor="let e of FilteredEmps">
            <td>{{e.EmpNo}}</td>
            <td>{{e.EmpName}}</td>
              <td>{{e.DeptNo}}</td>
            </tr>
         </tbody>
      </table>
      <hr>
    `
})
export class EmployeeReceiverComponent implements OnInit {
    emp: Employee;
    emps = Emps;
    DeptNo: number;
    _FilteredEmps: Array<Employee>;

    constructor(private serv: CommunicationService) {
        this.emp = new Employee(0, '', 0);
        this.DeptNo = 0;
        this._FilteredEmps = new Array<Employee>();
    }



    // read-only property. This will be invoked when the Input property is 
    // updated
    get FilteredEmps(): Array<Employee> {
        this._FilteredEmps = new Array<Employee>();
        if (this.DeptNo > 0) {
            this._FilteredEmps = this.emps.filter((e, idx) => {
                return e.DeptNo == this.DeptNo;
            });
        } else {
            this._FilteredEmps = this.emps;
        }
        return this._FilteredEmps;
    }

    // subscribe to the event once
    // so that number of times an event is emitting the
    // subscription will be activated
    // and data will be received
    ngOnInit(): void {
        this.serv.onReceiveData.subscribe((param) => {
            this.DeptNo = param;
            console.log(param);
        });
    }
}
