import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/models/app.product.model';
import { ProductLogic } from 'src/app/models/app.product.logic';
import { Categories, Manufacturers } from 'src/app/models/app.constants';

@Component({
    selector: 'app-product-component',
    templateUrl: 'app.product.view.html'
})
export class ProductComponent implements OnInit {
    product: Product;
    products: Array<Product>;
    private logic: ProductLogic;
    categories = Categories;
    manufacturers = Manufacturers;
    tableHeaders: Array<string>;
    isFormSubmitted: boolean;
    constructor() {
        this.product = new Product(0, '', '', 0, '', '', '');
        this.products = new Array<Product>();
        this.logic = new ProductLogic();
        this.tableHeaders = new Array<string>();
        this.isFormSubmitted = false;
    }

    // method that will be invoked immediately after the ctor
    ngOnInit(): void {
        // put properties of Product class in tableHeaders array
        for (let p in this.product) {
            this.tableHeaders.push(p);
        }
        this.products = this.logic.getProducts();

    }

    clear(): void {
        this.product = new Product(0, '', '', 0, '', '', '');
    }
    save(): void {
        this.products = this.logic.createProduct(this.product);
        this.isFormSubmitted = false;
    }

    getSelectedProduct(prd: Product): void {
        this.product = Object.assign({}, prd);
    }

    loadForm(): void {
        this.product = new Product(0, '', '', 0, '', '', '');
        this.isFormSubmitted = true;
    }
}
