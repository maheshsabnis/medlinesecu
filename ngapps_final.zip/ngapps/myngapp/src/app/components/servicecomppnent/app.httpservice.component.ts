import { Component, OnInit } from '@angular/core';
import { HttpAppService } from './../../services/app.httpapp.service';

import { ProductInfo } from './../../models/app.productinfo.model';

@Component({
    selector: 'app-httpservice-component',
    templateUrl: 'app.httpservice.view.html'
})
export class HttpServiceComponent implements OnInit {
    constructor(private serv: HttpAppService) { }

    ngOnInit(): void { }

    loadProduct(): void {
        this.serv.getProducts().subscribe((resp) => {
            console.log(JSON.stringify(resp));
        },
            (error) => {
                console.log(error.status);
            });
    }

    saveProduct(): void {
        let prd: ProductInfo = new ProductInfo(
            0, 'Prd1002', 'Iron', 2000, 'Electrical', 'ABC', 'Power-Press'
        );
        this.serv.postProduct(prd).subscribe((resp) => {
            console.log(JSON.stringify(resp));
        },
            (error) => {
                console.log(error.status);
            });
    }

    updateProduct(): void {

    }
}
