import { Component, OnInit } from '@angular/core';
import { Utilities } from './../../services/app.sample.service';

@Component({
    selector: 'app-sampleservice-component',
    template: `
      <div>{{message}}</div>
    `
})
export class SampleServiceComponent implements OnInit {
    message: string;
    constructor(private serv: Utilities) {
        this.message = '';
    }

    ngOnInit(): void {
        this.message = this.serv.changeCase('Angular Service', 'L');
    }
}
