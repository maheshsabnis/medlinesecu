import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-main-component',
    template: `
    <h1>The Angular Routing Application</h1>
      <table class="table table-bordered">
        <tr>
            <td>
              <a [routerLink]="['']">Home</a>
            </td>
             <td>
              <a [routerLink]="['/about',value]">About</a>
            </td>
             <td>
              <a [routerLink]="['contact']">contact</a>
            </td>
        </tr>
      </table>
      <br/>
      <router-outlet></router-outlet>
    `
})
export class MainComponent implements OnInit {
    value: number;
    constructor() {
        this.value = 1000;
    }

    ngOnInit(): void { }
}
