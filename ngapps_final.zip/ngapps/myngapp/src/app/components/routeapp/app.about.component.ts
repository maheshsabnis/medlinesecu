import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
    selector: 'app-about-component',
    template: `
      <h2>About Component</h2>
      <div>{{message}}</div>
      <input type="button" value="Navigate" (click)="navigate()"/>
    `
})
export class AboutComponent implements OnInit {
    message: string;
    constructor(private router: Router, private acr: ActivatedRoute) {
        this.message = 'This is About Component';
    }

    navigate(): void {
        this.router.navigate(['contact']);
    }
    // subscribe to route paramter once for the loading component
    ngOnInit(): void {
        this.acr.params.subscribe((p) => {
            this.message += p.id;
        });
    }
}
