import { Component, OnInit } from '@angular/core';
import { ProductInfo } from './../../models/app.productinfo.model';
@Component({
    selector: 'app-pipe-component',
    template: `
      <h2>Angular Pipes</h2>
      <div>{{name|uppercase}}</div>
      <br>
      <div>{{name|lowercase}}</div>
      <br>
      <div>{{birthDate|date:'full'}}</div>
      <br>
      <div>{{birthDate|date:'dd/MM/yyyy'}}</div>
      <br>
      <div>{{prd|json}}</div>
      <br/>
      <div>{{salary|currency:'JPY':true}}</div>
    `
})
export class PipedComponent implements OnInit {
    name: string;
    birthDate: Date;
    prd: ProductInfo;
    salary: number;
    constructor() {
        this.name = 'Mahesh';
        this.birthDate = new Date(1976, 7, 7);
        this.prd = new ProductInfo(1, 'Prd0001', 'P1', 1200, 'C1', 'M1', 'D1');
        this.salary = 120000;
    }

    ngOnInit(): void { }
}
