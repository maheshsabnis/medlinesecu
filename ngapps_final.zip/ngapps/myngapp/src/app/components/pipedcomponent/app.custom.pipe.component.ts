import { Component, OnInit } from '@angular/core';
import { Product } from './../../models/app.product.model';
@Component({
    selector: 'app-custompipe-component',
    templateUrl: './app.custompipe.view.html'
})
export class CustomPipeComponent implements OnInit {
    products: Array<Product>;
    value: number;
    constructor() {
        this.value = 0;
        this.products = new Array<Product>();

        this.products.push(new Product(1, 'Prd101', 'Laptop', 100000, 'Electronics', 'IBM', '64 GB'));
        this.products.push(new Product(2, 'Prd102', 'Iron', 1000, 'Electrical', 'Bajaj', 'Power Press'));
        this.products.push(new Product(3, 'Prd103', 'Desktop', 30000, 'Electronics', 'Lenovo', '4 GB'));
        this.products.push(new Product(4, 'Prd104', 'Cleaner', 6000, 'Electrical', 'TATA', 'Clean-booster'));
    }

    setValue(): void {
        this.value = 0;
    }

    ngOnInit(): void { }
}
