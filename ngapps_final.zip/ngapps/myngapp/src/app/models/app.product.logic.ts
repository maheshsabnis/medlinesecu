import { Product } from './app.product.model';

export class ProductLogic {
    private products: Array<Product>;

    constructor() {
        this.products = new Array<Product>();

        this.products.push(new Product(1, 'Prd0001', 'Laptop', 120000, 'Electronics', 'IBM', 'Core-i8 1 TB SSD'));
        this.products.push(new Product(2, 'Prd0002', 'Power-Grinder', 10000, 'Electrical', 'Bajaj', '1L RPM'));
        this.products.push(new Product(3, 'Prd0003', 'Lays', 20, 'Food', 'Parle', 'Big Size Chips'));
    }

    getProducts(): Array<Product> {
        return this.products;
    }

    createProduct(prd: Product): Array<Product> {
        this.products.push(prd);
        return this.products;
    }
}
