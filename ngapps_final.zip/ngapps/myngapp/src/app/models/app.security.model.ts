export class Register {
    constructor(
        public Email: string,
        public Password: string,
        public ConfirmPassword: string
    ) { }
}

export class Login {
    constructor(
        public UserName: string,
        public Password: string
    ) { }
}

export class ResponseData {
    constructor(
        public Message: string
    ) {

    }
}

export class ProductResponse {
    constructor(
        public ProductRowId: number,
        public ProductName: string,
        public Price: number
    ) { }
}

export class AuthValue {
    public TokenValue: string;
}
