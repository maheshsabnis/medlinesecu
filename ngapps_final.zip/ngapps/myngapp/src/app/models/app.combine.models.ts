export class Department {
    constructor(
        public DeptNo: number,
        public DeptName: string
    ) { }
}

export class Employee {
    constructor(
        public EmpNo: number,
        public EmpName: string,
        public DeptNo: number
    ) {
    }
}

export const Depts: Array<Department> = new Array<Department>();
Depts.push(new Department(101, 'D1'));
Depts.push(new Department(102, 'D2'));
Depts.push(new Department(103, 'D3'));

export const Emps: Array<Employee> = new Array<Employee>();
Emps.push(new Employee(1, 'A', 101));
Emps.push(new Employee(2, 'B', 102));
Emps.push(new Employee(3, 'C', 103));
Emps.push(new Employee(4, 'D', 101));
Emps.push(new Employee(5, 'E', 102));
Emps.push(new Employee(6, 'F', 103));
