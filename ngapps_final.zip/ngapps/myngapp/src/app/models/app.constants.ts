export const Categories = [
    'Electronics',
    'Electrical',
    'Food'
];

export const Manufacturers = [
    'IBM',
    'Bajaj',
    'Parle'
];
