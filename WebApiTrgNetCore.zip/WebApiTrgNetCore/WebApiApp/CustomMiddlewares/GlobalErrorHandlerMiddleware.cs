﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiApp.CustomMiddlewares
{

    public class ErrorObject
    {
        public int ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
    }

    /// <summary>
    /// Middleware Logic Class
    /// </summary>
    public class ErrorHandlerMiddleware
    {
        RequestDelegate requestDelegate;
        public ErrorHandlerMiddleware(RequestDelegate requestDelegate)
        {
            this.requestDelegate = requestDelegate;
        }
        /// <summary>
        /// Method that will Contain Logic for Middleware
        /// This may optionally call helper method that contains logic
        /// </summary>
        /// <param name="httpContext"></param>
        /// <returns></returns>
        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                // if the middleware succesfully executes then 
                // go to next midddleware in Http pipeline (Request and Response)
                await requestDelegate(httpContext);
            }
            catch (Exception ex)
            {
                // logic for Exceptions
                HandleExceptionAsync(httpContext, ex);
            }
        }

        private void HandleExceptionAsync(HttpContext context, Exception ex)
        {
            // 1. Manage the Error message
            context.Response.StatusCode = 500;
            context.Response.ContentType = "application/json";
            // 2. Write the Response
            var errorObject = new ErrorObject()
            {
                 ErrorCode = context.Response.StatusCode,
                 ErrorMessage = ex.Message
            };

            var errorResponse = JsonConvert.SerializeObject(errorObject);
            // 2a. This line will intercept the Http Request
            // and generate Http Response without further execution
            // on server
            context.Response.WriteAsync(errorResponse);
        }

    }

    /// <summary>
    /// Extension class that will be used to Register Custom Middleware
    /// </summary>
    public static class CustomMiddlewareRegistration
    {
        public static void UseGlobalErrorMiddlware(this IApplicationBuilder app)
        {
            app.UseMiddleware<ErrorHandlerMiddleware>();
        }
    }
}
