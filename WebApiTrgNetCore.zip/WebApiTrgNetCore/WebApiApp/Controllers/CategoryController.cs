﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApiApp.CustomFilters;
using WebApiApp.Models;
using WebApiApp.Services;
namespace WebApiApp.Controllers
{
     
    [Route("api/[controller]")]
    [ApiController] // new in asp.ner core 2.1+
    [LogFilter]
    public class CategoryController : ControllerBase
    {
        IService<Category, int> catService;
        public CategoryController(IService<Category, int> catService)
        {
            this.catService = catService;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var res =  catService.GetAsync().Result;
            return Ok(res);
        }
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var res = catService.GetAsync(id).Result;
            return Ok(res);
        }

        //[HttpPost("{catId}/{catName}/{basePrice}")]
        [HttpPost]
        public IActionResult Post(Category category)
       // public IActionResult Post(string catId, string catName, int basePrice)
        {
            //Category category = new Category() {
            //     CategoryId = catId,
            //     CategoryName = catName,
            //     BasePrice = basePrice
            //};
            
                if (ModelState.IsValid)
                {
                    if (category.BasePrice < 0) throw new Exception("Base Price cannot be -ve");
                    category = catService.CreateAsync(category).Result;
                    return Ok(category);
                }
                return BadRequest(ModelState);
        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, Category category)
        {
            if (ModelState.IsValid)
            {
                category = catService.UpdateAsync(id, category).Result;
                return Ok(category);
            }
            return BadRequest(ModelState);
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var res = catService.DeleteAsync(id).Result;
            return Ok(res);
        }

    }
}