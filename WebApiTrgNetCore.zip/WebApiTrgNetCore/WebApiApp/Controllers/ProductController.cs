﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApiApp.Models;
using WebApiApp.Services;
namespace WebApiApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        IService<Product, int> prdService;
        public ProductController(IService<Product, int> prdService)
        {
            this.prdService = prdService;
        }


        [HttpGet]
        public IActionResult Get()
        {
            var res = prdService.GetAsync().Result;
            return Ok(res);
        }
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var res = prdService.GetAsync(id).Result;
            return Ok(res);
        }

        //[HttpPost("{catId}/{catName}/{basePrice}")]
        [HttpPost]
        public IActionResult Post(Product product)
        {
            if (ModelState.IsValid)
            {
                product = prdService.CreateAsync(product).Result;
                return Ok(product);
            }
            return BadRequest(ModelState);

        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, Product product)
        {
            if (ModelState.IsValid)
            {
                product = prdService.UpdateAsync(id, product).Result;
                return Ok(product);
            }
            return BadRequest(ModelState);
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var res = prdService.DeleteAsync(id).Result;
            return Ok(res);
        }
    }
}