﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApiApp.Models;
using WebApiApp.Services;

namespace WebApiApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CombineController : ControllerBase
    {
        IService<Category, int> cService;
        IService<Product, int> pService;
        public CombineController(IService<Category, int> cService,
            IService<Product, int> pService)
        {
            this.cService = cService;
            this.pService = pService;
        }


        [HttpPost]
        public IActionResult Post(CategoryProduct categoryProduct)
        {
            cService.CreateAsync(categoryProduct.Category);
            foreach (var p in categoryProduct.Products)
            {
                pService.CreateAsync(p);
            }

            return Ok("Commit Successfully");
        }
    }
}