﻿using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Mvc;

namespace WebApiApp.CustomFilters
{
    public class LogFilterAttribute : ActionFilterAttribute
    {
        void LogInfo(string curState, RouteData route)
        {
            var logInfo = $" Current Execution State is {curState} " +
                $" in Controller {route.Values["controller"]} in action " +
                $"{route.Values["action"]}";
            Debug.Write(logInfo);
        }
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            LogInfo("OnActionExecuting", context.RouteData);
        }
        public override void OnActionExecuted(ActionExecutedContext context)
        {
            LogInfo("OnActionExecuted", context.RouteData);
        }
    }


    public class ProcessExceptionFilterAttribute : ExceptionFilterAttribute
    {
        public override void OnException(ExceptionContext context)
        {
            // 1. Handle Exception
            context.ExceptionHandled = true;
            // 2. Process the Logic
            var errorMessage = context.Exception.Message;
            // send the Http Response Message as Result
            BadRequestObjectResult badRequest 
                = new BadRequestObjectResult(errorMessage);
            context.Result = badRequest;
        }
    }
}
