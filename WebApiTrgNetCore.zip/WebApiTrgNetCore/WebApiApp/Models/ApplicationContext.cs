﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiApp.Models
{
    /// <summary>
    /// The clss for
    /// 1. Table Mapping if they are already preset
    /// 2. Generate Tables using Migration with the help of DbSet<T>
    /// 3. Manage DB Transactions over DbSet<T>
    /// </summary>
    public class ApplicationContext : DbContext
    {
        /// <summary>
        /// Read the DbContext Registered object from DI Container
        /// </summary>
        /// <param name="options"></param>
        public ApplicationContext(DbContextOptions<ApplicationContext> options)
            : base(options)
        {
        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }

        /// <summary>
        ///  Use Migrations to Create Model Mapping
        /// </summary>
        /// <param name="modelBuilder"></param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

    }
}
