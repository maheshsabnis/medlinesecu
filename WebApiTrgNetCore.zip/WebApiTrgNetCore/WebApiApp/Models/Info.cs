﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiApp.Models
{
    public class Info
    {
        public string Title { get; set; }
        public string Version { get; set; }
    }
}
