﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiApp.Models;

namespace WebApiApp.Services
{
    public class ProductService : IService<Product, int>
    {
        private ApplicationContext ctx;
        /// <summary>
        /// Inject the ApplicationContext from DI Container provided by Host
        /// </summary>
        /// <param name="ctx"></param>
        public ProductService(ApplicationContext ctx)
        {
            this.ctx = ctx;
        }

        public async Task<Product> CreateAsync(Product entity)
        {
           await ctx.Products.AddAsync(entity);
           await ctx.SaveChangesAsync();
           return entity;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            bool isDeleted = false;
            var res = ctx.Products.Find(id);
            if (res != null)
            {
                ctx.Products.Remove(res);
                await ctx.SaveChangesAsync();
                isDeleted = true;
            }
            return isDeleted;
        }

        public async Task<IEnumerable<Product>> GetAsync()
        {
            var res = await ctx.Products.ToListAsync();
            return res;
        }

        public  async Task<Product> GetAsync(int id)
        {
            var res = await ctx.Products.FindAsync(id);
            return res;
        }

        public async Task<Product> UpdateAsync(int id, Product entity)
        {
            var res = ctx.Products.Find(id);
            if (res != null)
            {
                res.ProductName = entity.ProductName;
                res.Price = entity.Price;
                res.CategoryRowId = entity.CategoryRowId;
                await ctx.SaveChangesAsync();
            }
            return res;
        }
    }
}
