﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiApp.Models;

namespace WebApiApp.Services
{
    public class CategoryService : IService<Category, int>
    {
        private ApplicationContext ctx;
        /// <summary>
        /// Inject the ApplicationContext from DI Container provided by Host
        /// </summary>
        /// <param name="ctx"></param>
        public CategoryService(ApplicationContext ctx)
        {
            this.ctx = ctx;
        }

        public async Task<Category> CreateAsync(Category entity)
        {
           await ctx.Categories.AddAsync(entity);
           await ctx.SaveChangesAsync();
           return entity;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            bool isDeleted = false;
            var res = ctx.Categories.Find(id);
            if (res != null)
            {
                ctx.Categories.Remove(res);
                await ctx.SaveChangesAsync();
                isDeleted = true;
            }
            return isDeleted;
        }

        public async Task<IEnumerable<Category>> GetAsync()
        {
            var res = await ctx.Categories.ToListAsync();
            return res;
        }

        public  async Task<Category> GetAsync(int id)
        {
            var res = await ctx.Categories.FindAsync(id);
            return res;
        }

        public async Task<Category> UpdateAsync(int id, Category entity)
        {
            var res = ctx.Categories.Find(id);
            if (res != null)
            {
                res.CategoryName = entity.CategoryName;
                res.BasePrice = entity.BasePrice;
                await ctx.SaveChangesAsync();
            }
            return res;
        }
    }
}
