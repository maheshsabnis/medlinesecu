import { AdminApproveComponent } from './components/adminOperations/app.admin.approve.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/app.home.component';
import { AdminComponent } from './components/admin/app.admin.component';
import { ManagerComponent } from './components/manager/app.manager.component';
import { ClerkComponent } from './components/clerk/app.clerk.component';
import { AuthComponent } from './components/auth/app.auth.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AdminComponent,
    ManagerComponent,
    ClerkComponent,
    AuthComponent,
    AdminApproveComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, FormsModule, HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
