export class User {
  public username: string;
  public password: string;
}

export class Response {
  public username: string;
  public token: string;
  public role: string;
}
export enum AppRoles {
  Admin = 'Admin',
  Manager = 'Manager',
  Clerk = 'Clerk'
}
