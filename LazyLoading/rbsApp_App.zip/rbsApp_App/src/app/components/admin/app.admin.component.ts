import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-component',
  templateUrl: 'app.admin.view.html'
})

export class AdminComponent implements OnInit {
  constructor() {
    alert("I am in Admin");
  }

  ngOnInit() { }
}
