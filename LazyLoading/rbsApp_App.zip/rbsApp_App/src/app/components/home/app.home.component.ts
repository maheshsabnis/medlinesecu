import { Component, OnInit } from '@angular/core';
import { Response } from "./../../models/app.model";
import { AuthenticateService } from "./../../services/AuthService.service";
@Component({
  selector: 'app-home-component',
  templateUrl: 'app.home.view.html'
})

export class HomeComponent implements OnInit {
  loginInfo: Response;
  constructor(private serv: AuthenticateService) {
    this.loginInfo = new Response();
    this.loginInfo = this.serv.currentUserInfo;

  }

  ngOnInit() { }
}
