import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clerk-component',
  templateUrl: 'app.clerk.view.html'
})

export class ClerkComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
