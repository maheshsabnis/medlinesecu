import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manager-component',
  templateUrl: 'app.manager.view.html'
})

export class ManagerComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
