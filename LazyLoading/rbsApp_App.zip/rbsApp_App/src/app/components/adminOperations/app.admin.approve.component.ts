import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-approve-component',
  template: `
    <h2>Admin Approve the JOB</h2>
    <div class="container">{{message}}</div>
  `
})

export class AdminApproveComponent implements OnInit {
  message: string;
  constructor() {
    this.message = "Approve the JOB";
  }

  ngOnInit() { }
}

