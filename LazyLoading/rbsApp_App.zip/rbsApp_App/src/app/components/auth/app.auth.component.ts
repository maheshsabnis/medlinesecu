import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { User } from "./../../models/app.model";
import { first } from 'rxjs/operators';
import { AuthenticateService } from 'src/app/services/AuthService.service';
@Component({
  selector: 'app-auth-component',
  templateUrl: 'app.auth.view.html'
})

export class AuthComponent implements OnInit {
  user: User;
  returnUrl: string;
  error = '';
  loading = false;
  constructor(private route: ActivatedRoute, private router: Router, private serv: AuthenticateService,
  ) {
    this.user = new User();
    if (this.serv.currentUserInfo) {
      this.router.navigate(['/']);
    }
  }

  ngOnInit() {
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }

  login(): void {
    this.serv.login(this.user)
      .pipe(first())
      .subscribe(
        data => {
          this.router.navigate([this.returnUrl]);
        },
        error => {
          this.error = error;
          this.loading = false;
        });
  }
  clear(): void {
    this.user = new User();
  }

}
