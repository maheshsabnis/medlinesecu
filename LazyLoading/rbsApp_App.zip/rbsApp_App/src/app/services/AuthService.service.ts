import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User, Response } from "./../models/app.model";
import { Observable, BehaviorSubject } from "rxjs";
import { map } from 'rxjs/operators';
@Injectable({ providedIn: 'root' })
export class AuthenticateService {
  private url: string;
  private authUserSubject: BehaviorSubject<Response>;
  public authUser: Observable<Response>;
  constructor(private httpClient: HttpClient) {
    this.url = "http://localhost:49950/api";
    this.authUserSubject = new BehaviorSubject<Response>(JSON.parse(localStorage.getItem('roleInfo')));
    this.authUser = this.authUserSubject.asObservable();
  }

  public get currentUserInfo(): Response {
    return this.authUserSubject.value;
  }


  login(user: User): any {

    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    return this.httpClient.post<Response>
      (`${this.url}/Account/Login`, user, options)
      .pipe(map(resp => {
        // login successful if there's a jwt token in the response
        if (resp && resp.token) {
          // store user details and jwt token in local storage
          // to keep user logged in between page refreshes
          localStorage.setItem('roleInfo', JSON.stringify(resp));
          this.authUserSubject.next(resp);

        }
        return resp;
      }));
  }

  logout(): void {
    // remove user from local storage to log user out
    localStorage.removeItem('roleInfo');
    this.authUserSubject.next(null);
  }


}
