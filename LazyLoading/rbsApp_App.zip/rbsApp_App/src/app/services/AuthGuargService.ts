import { Injectable } from '@angular/core';
import {
  Router,
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot
} from "@angular/router";
import { AuthenticateService } from './AuthService.service';
@Injectable({ providedIn: 'root' })
export class AuthGuardService implements CanActivate {

  constructor(
    private router: Router,
    private authenticationService: AuthenticateService
  ) { }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    alert('Auth guard service is called');
    const loginUser = this.authenticationService.currentUserInfo;
    alert(`In Auth guard service ${JSON.stringify(loginUser)}`);
    if (loginUser) {
      // check if route is restricted by role
      if (route.data.roles &&
        route.data.roles.indexOf(loginUser.role) === -1
      ) {
        alert('not authorized');
        // role not authorised so redirect to home page
        this.router.navigate(["/"]);
        return false;
      }
      // authorised so return true
      return true;
    }
    // not logged in so redirect to login page with the return url
    this.router.navigate(["/login"], { queryParams: { returnUrl: state.url } });
    return false;
  }
}

