import { AppRoles } from './models/app.model';
import { AdminApproveComponent } from './components/adminOperations/app.admin.approve.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/app.home.component';
import { AuthGuardService } from './services/AuthGuargService';
import { AdminComponent } from './components/admin/app.admin.component';
import { AuthComponent } from './components/auth/app.auth.component';
import { ClerkComponent } from './components/clerk/app.clerk.component';
import { ManagerComponent } from './components/manager/app.manager.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'admin',
    component: AdminComponent,
    canActivate: [AuthGuardService],
    data: { roles: [AppRoles.Admin] },
    children: [
      { path: 'approve', component: AdminApproveComponent }
    ]
  },
  {
    path: 'login',
    component: AuthComponent
  },
  {
    path: 'clerk',
    component: ClerkComponent,
    canActivate: [AuthGuardService],
    data: { roles: [AppRoles.Clerk] }
  },
  {
    path: 'manager',
    component: ManagerComponent,
    canActivate: [AuthGuardService],
    data: { role: [AppRoles.Manager] }
  },
  // otherwise redirect to home
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
