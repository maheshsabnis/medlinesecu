import { Component } from '@angular/core';
import { Router } from "@angular/router";
import { User, Response, AppRoles } from "./models/app.model";
import { AuthenticateService } from './services/AuthService.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  logUser: Response;

  constructor(private router: Router,
    private authService: AuthenticateService) {

    this.logUser = new Response();

    this.authService.authUser.subscribe(user => {
      this.logUser = user;
    });
  }

  get isAdmin() {
    return this.logUser && this.logUser.role === AppRoles.Admin;
  }
  get isManager() {
    return this.logUser && this.logUser.role === AppRoles.Manager;
  }
  get isClerk() {
    return this.logUser && this.logUser.role === AppRoles.Clerk;
  }
  logout() {
    this.authService.logout();
    this.router.navigate(["/login"]);
  }
}
